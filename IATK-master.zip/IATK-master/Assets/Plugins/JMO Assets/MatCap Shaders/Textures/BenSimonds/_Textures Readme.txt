All textures in this folder created by Ben Simonds, licensed under a Creative Commons Attribution 3.0 Unported License.
http://creativecommons.org/licenses/by/3.0/

Based on a work at bensimonds.com
Original source: http://bensimonds.com/2010/07/30/matcap-generator/